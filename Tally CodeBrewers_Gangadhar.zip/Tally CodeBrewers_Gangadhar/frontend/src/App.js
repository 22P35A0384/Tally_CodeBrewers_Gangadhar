import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Codeeditor from './pages/editor';
import Compiler from './pages/compiler';
import HomePage from './pages/home';
import Login from './pages/login';
import Test from './pages/test';
import AddProblems from './pages/addproblem';
import Logout from './pages/logout';
import ContestPage from './pages/contest';
import CreateContestPage from './pages/createcontest';
import SingleContestPage from './pages/singlecontest';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/editor" element={<Codeeditor />} />
          <Route path="/compiler" element={<Compiler />} />
          <Route path='/home' element={<HomePage />} />
          <Route path='/' element={<Login />} />
          <Route path='/login' element={<Login />} />
          <Route path='/test' element={<Test />} />
          <Route path='/addproblem' element={<AddProblems />} />
          <Route path='/logout' element={<Logout/>}/>
          <Route path='/contests' element={<ContestPage/>}/>
          <Route path='/createcontest' element={<CreateContestPage/>}/>
          <Route path='/contest/:id' element={<SingleContestPage/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
