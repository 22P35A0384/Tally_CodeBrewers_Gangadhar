import { useNavigate } from "react-router-dom";

const Logout=()=>{
    const navigate = useNavigate()
    localStorage.removeItem("tallyuser")
    window.location.href='/login'
    return(
        <></>
    )
}

export default Logout;