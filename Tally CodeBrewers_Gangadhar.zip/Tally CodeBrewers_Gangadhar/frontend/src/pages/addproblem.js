import React, { useState, useEffect } from "react";
import {
  Box,
  ButtonGroup,
  Button,
  Tooltip,
  TextField,
  Grid,
  Typography,
  Input,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from "@mui/material";
import { Image, Link as LinkIcon } from "@mui/icons-material";
import styles from "../css/addproblem.module.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const AddProblems = () => {
    const [userName, setUsername] = useState('')
    useEffect(()=>{
        const user =JSON.parse(localStorage.getItem("tallyuser"))
        if(!user){
            window.location.href="/login"
        }else{
            setUsername(user.username)
        }
    },[])
  const [content, setContent] = useState("");
  const [images, setImages] = useState([]);
  const [linkURL, setLinkURL] = useState("");
  const [openLinkDialog, setOpenLinkDialog] = useState(false);
  const [problemStatement, setProblemStatement] = useState("");
  const [description, setDescription] = useState("");
  const [sampleInputs, setSampleInputs] = useState([
    { input: "", output: "", explanation: "" },
    { input: "", output: "", explanation: "" },
  ]);
  const [hiddenTestCases, setHiddenTestCases] = useState([
    { input: "", output: "" },
    { input: "", output: "" },
    { input: "", output: "" },
  ]);
  const [errors, setErrors] = useState({});

  const handleFormatting = (command) => {
    document.execCommand(command);
  };

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    const imagePreviews = files.map((file) => URL.createObjectURL(file));
    setImages([...images, ...imagePreviews]);
  };

  const handleInsertLink = () => {
    const selection = window.getSelection();
    if (selection.rangeCount > 0 && linkURL) {
      const range = selection.getRangeAt(0);
      const selectedText = range.toString();
      if (selectedText) {
        const anchor = document.createElement("a");
        anchor.href = linkURL;
        anchor.target = "_blank"; // Open in new tab
        anchor.innerHTML = selectedText;
        range.deleteContents();
        range.insertNode(anchor);
        setOpenLinkDialog(false);
        setLinkURL("");
        setContent(document.querySelector("[contentEditable]").innerHTML);
      }
    }
  };

  const validateInputs = () => {
    const newErrors = {};
    if (!problemStatement)
      newErrors.problemStatement = "Problem Statement is required";
    if (!description) newErrors.description = "Description is required";
    sampleInputs.forEach((sample, index) => {
      if (!sample.input || !sample.output || !sample.explanation) {
        newErrors[`sampleInput${index}`] = "All fields are required";
      }
    });
    hiddenTestCases.forEach((testCase, index) => {
      if (!testCase.input || !testCase.output) {
        newErrors[`hiddenTestCase${index}`] = "All fields are required";
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async() => {
    if (validateInputs()) {
      // Create a data object with all the filled data
      const data = {
        problemStatement,
        description,
        sampleInputs,
        hiddenTestCases,
        images, // Include images if needed
        content, // Include editor content if needed
      };
  
      // For demonstration purposes, we'll log the data object
      console.log("Submitted Data:", data);
  
      await axios.post('http://localhost:5000/addproblem',data).then((res)=>{
        if(res.data===true){
            alert("Submitted successfully");
            window.location.reload()
        }else{
            alert(res.data)
        }
      })
    }
  };
  

  const handleSampleInputChange = (index, field, value) => {
    const updatedSampleInputs = [...sampleInputs];
    updatedSampleInputs[index][field] = value;
    setSampleInputs(updatedSampleInputs);
  };

  const handleHiddenTestCaseChange = (index, field, value) => {
    const updatedTestCases = [...hiddenTestCases];
    updatedTestCases[index][field] = value;
    setHiddenTestCases(updatedTestCases);
  };
  const navigate = useNavigate();

  return (
    <Grid container className={styles.container}>
        <Button
            className={styles.backbtn}
            variant="outlined"
            startIcon= {<ArrowBackIosIcon />}
            onClick={()=>{navigate('/home')}}
            >
            Back TO Home
        </Button>
      {/* Editor Section */}
      <Grid item xs={12} className={styles.editorSection}>
        <Box className={styles.toolbar}>
          <ButtonGroup
            variant="outlined"
            aria-label="insert options"
            className={styles.buttonGroup}
          >
            <Tooltip title="Upload Image">
              <Input
                accept="image/*"
                id="image-upload"
                type="file"
                style={{ display: "none" }}
                multiple
                onChange={handleImageUpload}
              />
              <label htmlFor="image-upload">
                <Button component="span">
                  <Image />
                </Button>
              </label>
            </Tooltip>
            <Tooltip title="Insert Link">
              <Button onClick={() => setOpenLinkDialog(true)}>
                <LinkIcon />
              </Button>
            </Tooltip>
          </ButtonGroup>
          <Button
            className={`${styles.previewButton} ${styles.blueButton}`}
            variant="contained"
            onClick={handleSubmit}
          >
            Submit
          </Button>
        </Box>
        <Typography variant="h6">Adding New Problem</Typography>
        <TextField
          label={"Problem Statement"}
          variant="outlined"
          fullWidth
          className={styles.textField}
          value={problemStatement}
          onChange={(e) => setProblemStatement(e.target.value)}
          error={!!errors.problemStatement}
          helperText={errors.problemStatement}
        />
        <TextField
          label={"Description"}
          variant="outlined"
          fullWidth
          className={styles.textField}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          error={!!errors.description}
          helperText={errors.description}
        />

        {/* Sample Inputs Section */}
        <Box className={styles.sampleInputsSection}>
          <Typography variant="h6">Sample Inputs</Typography>
          {sampleInputs.map((sample, index) => (
            <Box key={index} className={styles.sampleInput}>
              <TextField
                label={`Input ${index + 1}`}
                variant="outlined"
                fullWidth
                className={styles.textField}
                value={sample.input}
                onChange={(e) =>
                  handleSampleInputChange(index, "input", e.target.value)
                }
                error={!!errors[`sampleInput${index}`]}
                helperText={errors[`sampleInput${index}`]}
              />
              <TextField
                label={`Output ${index + 1}`}
                variant="outlined"
                fullWidth
                className={styles.textField}
                value={sample.output}
                onChange={(e) =>
                  handleSampleInputChange(index, "output", e.target.value)
                }
                error={!!errors[`sampleInput${index}`]}
                helperText={errors[`sampleInput${index}`]}
              />
              <TextField
                label={`Explanation ${index + 1}`}
                variant="outlined"
                fullWidth
                className={styles.textField}
                value={sample.explanation}
                onChange={(e) =>
                  handleSampleInputChange(index, "explanation", e.target.value)
                }
                error={!!errors[`sampleInput${index}`]}
                helperText={errors[`sampleInput${index}`]}
              />
            </Box>
          ))}
        </Box>

        {/* Hidden Test Cases Section */}
        <Box className={styles.hiddenTestCasesSection}>
          <Typography variant="h6">Hidden Test Cases</Typography>
          {hiddenTestCases.map((testCase, index) => (
            <Box key={index} className={styles.hiddenTestCase}>
              <TextField
                label={`Hidden Test Case ${index + 1} - Input`}
                variant="outlined"
                fullWidth
                className={styles.textField}
                value={testCase.input}
                onChange={(e) =>
                  handleHiddenTestCaseChange(index, "input", e.target.value)
                }
                error={!!errors[`hiddenTestCase${index}`]}
                helperText={errors[`hiddenTestCase${index}`]}
              />
              <TextField
                label={`Hidden Test Case ${index + 1} - Expected Output`}
                variant="outlined"
                fullWidth
                className={styles.textField}
                value={testCase.output}
                onChange={(e) =>
                  handleHiddenTestCaseChange(index, "output", e.target.value)
                }
                error={!!errors[`hiddenTestCase${index}`]}
                helperText={errors[`hiddenTestCase${index}`]}
              />
            </Box>
          ))}
        </Box>
      </Grid>

      {/* Insert Link Dialog */}
      <Dialog open={openLinkDialog} onClose={() => setOpenLinkDialog(false)}>
        <DialogTitle>Insert Link</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Enter the URL for the link you want to insert:
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            label="URL"
            type="url"
            fullWidth
            variant="standard"
            value={linkURL}
            onChange={(e) => setLinkURL(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenLinkDialog(false)}>Cancel</Button>
          <Button onClick={handleInsertLink}>Insert Link</Button>
        </DialogActions>
      </Dialog>
    </Grid>
  );
};

export default AddProblems;
