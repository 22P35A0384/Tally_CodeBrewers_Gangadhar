import React, { useState, useEffect } from "react";
import { Editor } from "@monaco-editor/react";
import Styles from "../css/editor.module.css";
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import LightModeIcon from '@mui/icons-material/LightMode';
import CachedIcon from '@mui/icons-material/Cached';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import FullscreenIcon from '@mui/icons-material/Fullscreen';
import FullscreenExitIcon from '@mui/icons-material/FullscreenExit';
import { Button, Select, MenuItem } from "@mui/material";
import axios from "axios";
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { useNavigate } from "react-router-dom";

const Codeeditor = () => {
    const [userName, setUsername] = useState('')
    useEffect(()=>{
        const user =JSON.parse(localStorage.getItem("tallyuser"))
        if(!user){
            window.location.href="/login"
        }else{
            setUsername(user.username)
        }
    },[])
    const navigate = useNavigate()
    const Cs = JSON.parse(localStorage.getItem('currentproblem'))
    const question = Cs.problemStatement;
    const openTestCases = Cs.sampleInputs;
    const hiddenTestCases = Cs.hiddenTestCases;
    const qno = localStorage.getItem('qn'); // Or any other identifier
    const description = Cs.description
  const [Language, setLanguage] = useState('python');
  const [ScreenMode, setScreenMode] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [timer, setTimer] = useState(0);
  const [isRunning, setIsRunning] = useState(true);
  const [codeContent, setCodeContent] = useState('');
  const [Custominput, setCustominput] = useState('');
  const [loading, setLoading] = useState(false);
  const handleCodeChange = (newValue) => {
    if (!isRunning) {
      setIsRunning(true);
    }
    setCodeContent(newValue);
  };

  const Code = {
    "python": `print("Hello World!")`,
    "javascript": `console.log("Hello, World!");`
  };

  useEffect(() => {
    setCodeContent(Code[Language]);
  }, [Language]);

  useEffect(() => {
    let interval = null;
    if (isRunning) {
      interval = setInterval(() => {
        setTimer((timer) => timer + 1);
      }, 1000);
    } else if (!isRunning && timer !== 0) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isRunning, timer]);

  useEffect(() => {
    setIsRunning(true);
  }, []);

  const formatTime = (totalSeconds) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const escapeHtml = (unsafe) => {
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  };

const handleRunCode = async () => {
    const outputDiv = document.querySelector(`.${Styles.consoleresult}`);
    if (!outputDiv) {
      console.error("Output element not found");
      return;
    }
  
    // Set loading state to true
    setLoading(true);
  
    // Clear previous output
    outputDiv.innerHTML = '';
  
    // Determine if custom input is used
    const isCustomInput = Custominput.trim() !== '';
    const inputToUse = isCustomInput ? Custominput : null;
  
    if (isCustomInput) {
      try {
        const response = await axios.post(`http://localhost:5000/${Language}`, {
          code: codeContent,
          input: inputToUse, // Use custom input
        });
  
        // Extract and sanitize the output
        const { output = '', error = '' } = response.data;
        const sanitizedOutput = output.trim().replace(/\r\n/g, '\n');
        
        // Display result
        outputDiv.innerHTML += `<div style="color: ${error ? 'red' : 'black'}; display: flex; flex-direction: column; margin-bottom: 10px;">
                                  <span><strong>Input:</strong> ${escapeHtml(inputToUse)}</span>
                                  <span><strong>Output:</strong> ${escapeHtml(sanitizedOutput.replace(/\n/g, '<br />'))}</span>
                                  ${error ? `<span style="color: red;"><strong>Error:</strong> ${escapeHtml(error)}</span>` : ''}
                                </div>`;
      } catch (error) {
        outputDiv.innerHTML += `<div style="color: red; display: flex; flex-direction: column; margin-bottom: 10px;">
                                  <span><strong>Error:</strong> ${escapeHtml(error.message)}</span>
                                </div>`;
      }
    } else {
      // Combine open and hidden test cases if no custom input
      const allTestCases = [...openTestCases, ...hiddenTestCases];
      let allPassed = true;
  
      for (let i = 0; i < allTestCases.length; i++) {
        const testCase = allTestCases[i];
        try {
          const response = await axios.post(`http://localhost:5000/${Language}`, {
            code: codeContent,
            input: testCase.input,
          });
  
          // Extract and sanitize the output
          const { output = '', error = '' } = response.data;
          const sanitizedOutput = output.trim().replace(/\r\n/g, '\n');
          const sanitizedExpectedOutput = testCase.output.trim().replace(/\r\n/g, '\n');
  
          const isPassed = sanitizedOutput === sanitizedExpectedOutput;
  
          // Display result for open test cases
          if (openTestCases.includes(testCase)) {
            outputDiv.innerHTML += `<div style="color: ${isPassed ? 'green' : 'red'}; display: flex; flex-direction: column; margin-bottom: 10px;">
                                      <span>Test Case ${i + 1}: ${isPassed ? 'Passed' : 'Failed'}</span>
                                      <span><strong>Input:</strong> ${escapeHtml(testCase.input)}</span>
                                      <span><strong>Expected:</strong> ${escapeHtml(testCase.output)}</span>
                                      <span><strong>Received:</strong> ${escapeHtml(sanitizedOutput.replace(/\n/g, '<br />'))}</span>
                                    </div>`;
          } else {
            // Display result for hidden test cases
            outputDiv.innerHTML += `<div style="color: ${isPassed ? 'green' : 'red'}; display: flex; flex-direction: column; margin-bottom: 10px;">
                                      <span>Test Case ${i + 1}: ${isPassed ? 'Passed' : 'Failed'}</span>
                                      <span><strong>Received:</strong> ${escapeHtml(sanitizedOutput.replace(/\n/g, '<br />'))}</span>
                                    </div>`;
          }
  
          if (!isPassed) {
            allPassed = false;
          }
        } catch (error) {
          outputDiv.innerHTML += `<div style="color: red; display: flex; flex-direction: column; margin-bottom: 10px;">
                                    <span>Test Case ${i + 1}: Error - ${escapeHtml(error.message)}</span>
                                  </div>`;
          allPassed = false;
        }
      }
  
      // Stop timer if all test cases pass
      if (allPassed) {
        setIsRunning(false);
      }
    }
  
    // Clear custom input after execution
    setCustominput('');
  
    // Set loading state to false
    setLoading(false);
  };
  
  
  
  

  const handleResetCode = () => {
    setTimer(0);
    setIsRunning(false);
    setCodeContent(Code[Language]);
  };


  const toggleFullscreen = () => {
    const editorElement = document.querySelector(`.${Styles.main}`);
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      editorElement.requestFullscreen();
    }
    setIsFullscreen(!isFullscreen);
  };

  const handleChange = (event) => {
    setLanguage(event.target.value);
  };

  const Userinput = (e) => {
    setCustominput(e.target.value);
  };

  return (
    <div className={Styles.main}>
      <div className={Styles.right}>
        <div className={Styles.rparent}>
            <Button
                className={Styles.backbtn}
                variant="outlined"
                startIcon= {<ArrowBackIosIcon />}
                disabled={loading}
                onClick={()=>{navigate('/home')}}
                >
                Back To Home
            </Button>
            <h1>Problem {qno} :</h1>
            <h2>{question}</h2>
            <p>{description}</p>
            <div className={Styles.testcases}>
                <h3>Sample Test Cases:</h3>
                {openTestCases.map((testCase, index) => (
                    <div key={index}>
                    <p><strong>Input:</strong> {testCase.input}</p>
                    <p><strong>Expected Output:</strong> {testCase.output}</p>
                    <p><strong>Explanation:</strong> {testCase.explanation}</p>
                    </div>
                ))}
            </div>
        </div>
      </div>
      <div className={Styles.left}>
        <div className={Styles.leftup}>
          <div className={Styles.head}>
            <div className={Styles.headright}>
              {/* <Button className={Styles.runbtn1} variant="outlined" endIcon={<PlayArrowIcon />} onClick={handleRunCode}>Run Code</Button> */}
              <Button
                className={Styles.runbtn1}
                variant="outlined"
                endIcon={loading ? null : <PlayArrowIcon />}
                disabled={loading}
                onClick={handleRunCode}
                >
                {loading ? <div className={Styles.spinner}></div> : 'Run Code'}
              </Button>
              {/* <Button className={Styles.runbtn2} variant="outlined" onClick={handleRunCode}><PlayArrowIcon /></Button> */}
              <Button
                className={Styles.runbtn2}
                variant="outlined"
                // endIcon={loading ? null : <PlayArrowIcon />}
                disabled={loading}
                onClick={handleRunCode}
                >
                {loading ? <div className={Styles.spinner}></div> : <PlayArrowIcon/>}
              </Button>
              {ScreenMode ? 
                <div onClick={() => setScreenMode(false)}>
                  <DarkModeIcon style={{cursor:'pointer', color: isFullscreen && !ScreenMode ? 'white' : 'inherit'}}/>
                </div> 
                : 
                <div onClick={() => setScreenMode(true)}>
                  <LightModeIcon style={{cursor:'pointer', color: isFullscreen && !ScreenMode ? 'white' : 'inherit'}}/>
                </div>
              }
              <CachedIcon style={{cursor:'pointer', color: isFullscreen && !ScreenMode ? 'white' : 'inherit'}} onClick={handleResetCode}/>
              {isFullscreen ? 
                <FullscreenExitIcon style={{cursor:'pointer', color: 'white'}} onClick={toggleFullscreen}/> 
                : 
                <FullscreenIcon style={{cursor:'pointer', color: isFullscreen && !ScreenMode ? 'white' : 'inherit'}} onClick={toggleFullscreen}/>
              }
              <h5 className={Styles.time} style={{ color: isFullscreen && !ScreenMode ? 'white' : 'inherit' }}>
                {formatTime(timer)}
              </h5>
            </div>
            <div>
              <Select
                style={{ height: '38px' }}
                value={Language}
                onChange={handleChange}
                displayEmpty
                inputProps={{ 'aria-label': 'Without label' }}
              >
                <MenuItem value="">
                  <em>Language</em>
                </MenuItem>
                <MenuItem value={'python'}>Python 3.10.0</MenuItem>
                <MenuItem value={'javascript'}>JavaScript 1.32.3</MenuItem>
              </Select>
            </div>
          </div>
          <div style={{border:'1px solid black'}}>
            <Editor
              height='90svh'
              width="100%"
              theme={ScreenMode ? "vs-light" : "vs-dark"}
              language={Language==='c++' ? "cpp" : Language}
              value={codeContent}
              onChange={(newValue) => handleCodeChange(newValue)}
            />
          </div>
        </div>
        <div className={Styles.leftdown}>
          <div className={Styles.input}>
            <div className={Styles.inputhead}>
              <h2>Custom Input :</h2>
            </div>
            <div className={Styles.inputbody}>
              <textarea value={Custominput} onChange={Userinput} className={Styles.inputinput}/>
            </div>
          </div>
          <div className={Styles.console}>
            <div className={Styles.consolehead}>
              <h2>Output :</h2>
            </div>
            <div className={Styles.consolebody}>
              <div className={Styles.consoleresult}></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};


export default Codeeditor;
