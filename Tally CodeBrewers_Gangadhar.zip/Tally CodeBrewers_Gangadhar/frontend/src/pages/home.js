import React, { useState, useEffect } from 'react';
import { Button, Typography, Box, Grid, Card, CardContent, CardActions } from '@mui/material';
import { AddCircle as AddCircleIcon, Create as CreateIcon } from '@mui/icons-material';
import axios from 'axios'; // Make sure axios is installed
import styles from '../css/home.module.css'; // Adjust the path to your CSS file
import { useNavigate } from 'react-router-dom';
import TerminalIcon from '@mui/icons-material/Terminal';
import AssessmentIcon from '@mui/icons-material/Assessment';

const HomePage = () => {
    const [userName, setUsername] = useState('')
    useEffect(()=>{
        const user =JSON.parse(localStorage.getItem("tallyuser"))
        if(!user){
            window.location.href="/login"
        }else{
            setUsername(user.username)
        }
    },[])
  const [problems, setProblems] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProblems = async () => {
      try {
        const response = await axios.get('http://localhost:5000/allqns');
        setProblems(response.data);
      } catch (error) {
        console.error('Error fetching problems:', error);
      }
    };

    fetchProblems();
  }, []);

  const handleSolve = (problem,n) => {
    console.log(problem,n)
    localStorage.setItem("currentproblem", JSON.stringify(problem))
    localStorage.setItem("qn", n)
    navigate('/editor');
  };

  return (
    <Box className={styles.container}>
      <Box className={styles.header}>
        <Typography variant="h6" className={styles.userName}>
          Welcome {userName},
        </Typography>
        <Box className={styles.buttonGroup}>
          <Button
            variant="contained"
            color="primary"
            startIcon={<TerminalIcon />}
            className={styles.addButton}
            onClick={()=>{navigate('/compiler')}}
          >
            Compiler
          </Button>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddCircleIcon />}
            className={styles.addButton}
            onClick={()=>{navigate('/addproblem')}}
          >
            Add New Question
          </Button>
          <Button
            variant="contained"
            color="secondary"
            startIcon={<AssessmentIcon />}
            className={styles.createButton}
            onClick={()=>{navigate('/contests')}}
          >
            Contests
          </Button>
        </Box>
      </Box>
      <Grid container spacing={2} className={styles.problemList}>
        {problems.map((problem, i) => (
          <Grid item xs={12} sm={6} md={4} key={problem._id}>
            <Card className={styles.problemCard}>
              <CardContent style={{textAlign:'left'}}>
                <Typography variant="h5" style={{color:'white'}}>
                  Question {i+1}
                </Typography>
                <Typography variant="h6" style={{color:'white'}}>
                  {problem.problemStatement}
                </Typography>
              </CardContent>
              <CardActions>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleSolve(problem,i+1)}
                >
                  Solve
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default HomePage;
