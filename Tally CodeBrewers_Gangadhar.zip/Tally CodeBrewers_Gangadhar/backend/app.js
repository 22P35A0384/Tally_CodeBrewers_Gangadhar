import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import bodyParser from 'body-parser';


// function imports
import Testing from "./src/routers/testrouter.js";
import Pythonapi from "./src/routers/pythonrouter.js";
import Javascriptapi from "./src/routers/javasrciptrouter.js";
import Addproblemapi from "./src/routers/addproblemrouter.js";
import Getallqnsapi from "./src/routers/getallqnsrouter.js";
import Newcontestapi from "./src/routers/contestrouter.js";
import Getcontestsapi from "./src/routers/getallcontestsrouter.js";
import Singlecontestapi from "./src/routers/singlecontestrouter.js";
import Singlequestionapi from "./src/routers/singleqnrouter.js";

const app = express();

app.use(bodyParser.json());
app.use(cors());

mongoose.connect('mongodb+srv://admin:cLBG7LhkqX7orsSy@tally-codebrewers.d2lej.mongodb.net/tally-codebrewers?retryWrites=true&w=majority&appName=Tally-CodeBrewers')
    .then(()=>app.listen(5000))
    .then(()=>console.log("Server Running on 5000 && Database Connected Sucessfully :)"))
    .catch((err)=>console.log(err))


// Producction Functions

app.use('/',Testing);
app.use('/',Pythonapi);
app.use('/',Javascriptapi);
app.use('/',Addproblemapi);
app.use('/',Getallqnsapi);
app.use('/',Newcontestapi);
app.use('/',Getcontestsapi);
app.use('/',Singlecontestapi);
app.use('/',Singlequestionapi);

// Testing Space

app.use("/api", (req, res, next)=>{
    res.send("hi hello")
})
