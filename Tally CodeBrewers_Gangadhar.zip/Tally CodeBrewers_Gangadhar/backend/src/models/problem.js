import { Schema as _Schema, model } from 'mongoose';
const Schema = _Schema;

// Define the schema for the problem
const ProblemSchema = new Schema({
  problemStatement: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  sampleInputs: [
    {
      input: {
        type: String,
        required: true,
      },
      output: {
        type: String,
        required: true,
      },
      explanation: {
        type: String,
        required: true,
      },
    },
  ],
  hiddenTestCases: [
    {
      input: {
        type: String,
        required: true,
      },
      output: {
        type: String,
        required: true,
      },
    },
  ],
  images: [
    {
      type: String, // Store image URLs or paths
    },
  ],
  content: {
    type: String, // Store editor content if needed
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Create and export the model
const Problem = model('Problem', ProblemSchema);

export default Problem;
