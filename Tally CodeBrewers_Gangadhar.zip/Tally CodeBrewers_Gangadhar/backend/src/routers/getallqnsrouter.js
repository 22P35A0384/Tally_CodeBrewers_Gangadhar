import Getallqns from "../controlers/getallqns.js";
import express from "express";

const Router = express.Router();

Router.get('/allqns', Getallqns);

export default Router;