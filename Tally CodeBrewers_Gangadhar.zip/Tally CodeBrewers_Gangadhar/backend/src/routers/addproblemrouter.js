import Addproblem from "../controlers/addproblem.js";
import express from "express";

const Router = express.Router();

Router.post('/addproblem',Addproblem);

export default Router;