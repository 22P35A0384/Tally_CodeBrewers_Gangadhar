import Problem from "../models/problem.js";

const Singleqn = async(req,res) =>{
    const id = req.params.id
    try {
        console.log(id)
        const contest = await Problem.findById(id);
        if (!contest) {
          return res.status(404).json({ message: 'Contest not found' });
        }
        res.json(contest);
      } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
      }
}

export default Singleqn;