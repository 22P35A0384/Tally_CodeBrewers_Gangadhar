import Problem from "../models/problem.js";

const Getallqns=async(req,res)=>{
    try {
        const problems = await Problem.find();
        res.status(200).json(problems);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
}

export default Getallqns;