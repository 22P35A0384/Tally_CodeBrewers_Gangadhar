import Problem from "../models/problem.js";

const Addproblem =  async (req, res) => {
    try {
      const {
        problemStatement,
        description,
        sampleInputs,
        hiddenTestCases,
        images,
        content,
      } = req.body;
  
      // Create a new problem instance
      const newProblem = new Problem({
        problemStatement,
        description,
        sampleInputs,
        hiddenTestCases,
        images,
        content,
      });
  
      // Save the problem to the database
      const result = await newProblem.save();
      
      // Send success response
      res.status(201).json(true);
    } catch (error) {
      console.error('Error saving problem:', error);
      res.status(500).json({
        message: 'Internal server error',
        error: error.message,
      });
    }
  };

  export default Addproblem;