1) download the zip file and extract the file in a folder

2) before starting the project you have to check some requirements
    - must have node installed and added to your system's path
    - must have python istalled and added to your systems's path
    - your laptop or pc is connected with good internet speed

3) now to goto root directory of the project (backend) and run the command "npm i" to install to node modules

4) now run the command "npm start" to start the backend

5) now goto the root directory of the project (frontend) and run the command "npm i" to install the node modules

6) now run the commant "npm start" to start the frontend

7) external libraries used
    - Material UI (for some good looking styles)
    - Monaco Editor (for code editor in compiler)

8) AI services used
    - used chat GPT for debugging unresolved errors